Ok so I know in the program description it says "Create a list of unique words using your LinkedList class". However I'm dumb and couldn't bug crush enough to get my linked list class to work.
so I decided that a working program is better than a non existent program. It uses java built in functions however it does use the built in sort function, which I feel like is kinda cheating
so I used lambda expressions to make it seem harder. Anyway I don't want it to seem like I gave up I included the linkedlist program files in the zip but they aren't used in the WordCount program.
 
